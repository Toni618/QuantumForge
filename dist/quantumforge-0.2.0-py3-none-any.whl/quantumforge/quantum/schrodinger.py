"""1-D stationary Schrodinger solver using a second-order finite difference Hamiltonian."""
from __future__ import annotations
import numpy as np
from scipy.linalg import eigh_tridiagonal

HBAR = 1.0  # Dimensionless units; set hbar=1 and mass=1 unless specified.

def solve_1d(potential, x_min=-8.0, x_max=8.0, points=1201, states=6, mass=1.0, hbar=HBAR):
    if points < 101 or points > 20001: raise ValueError("points must be in [101, 20001]")
    if states < 1 or states >= points-2: raise ValueError("Invalid number of eigenstates")
    if not x_min < x_max or mass <= 0 or hbar <= 0: raise ValueError("Invalid domain, mass, or hbar")
    x = np.linspace(x_min, x_max, points); dx=x[1]-x[0]
    v=np.asarray(potential(x),dtype=float)
    if v.shape != x.shape or not np.all(np.isfinite(v)): raise ValueError("Potential must return finite values matching the grid")
    kinetic = hbar*hbar/(2.0*mass*dx*dx)
    diagonal = 2.0*kinetic + v[1:-1]
    off = np.full(points-3, -kinetic)
    energies, vectors = eigh_tridiagonal(diagonal, off, select="i", select_range=(0,states-1))
    wavefunctions=[]; norms=[]
    for i in range(states):
        psi=np.zeros(points); psi[1:-1]=vectors[:,i]
        norm=float(np.trapezoid(np.abs(psi)**2,x))
        psi=psi/np.sqrt(norm)
        # deterministic phase convention: positive first significant sample
        nz=np.flatnonzero(np.abs(psi)>1e-12)
        if len(nz) and psi[nz[0]] < 0: psi=-psi
        wavefunctions.append(psi.tolist()); norms.append(float(np.trapezoid(np.abs(psi)**2,x)))
    return {"x":x.tolist(),"energies":energies.tolist(),"wavefunctions":wavefunctions,
            "normalization":norms,"grid_spacing":float(dx),"points":points,"states":states,
            "method":"second-order central finite differences + symmetric tridiagonal eigensolver",
            "boundary_condition":"Dirichlet psi(x_min)=psi(x_max)=0",
            "units":"dimensionless unless physical SI parameters are supplied",
            "limitations":["Finite domain and grid introduce discretization error.","Second-order spatial stencil.","This is a 1-D stationary solver, not a general 3-D or time-dependent solver."]}

def harmonic_oscillator(x, omega=1.0): return 0.5*omega*omega*x*x
