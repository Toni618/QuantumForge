"""Small state-vector quantum circuit simulator; little-endian qubit indexing."""
import numpy as np
I=np.eye(2,dtype=complex)
H=np.array([[1,1],[1,-1]],complex)/np.sqrt(2)
X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
Z=np.diag([1,-1]).astype(complex)

def _apply_single(state, gate, target, n):
    if target<0 or target>=n: raise ValueError("Target qubit out of range")
    tensor=state.reshape((2,)*n)
    axis=n-1-target  # reshape uses big-endian tensor axes; public qubit labels are little-endian
    moved=np.moveaxis(tensor,axis,0)
    updated=np.tensordot(gate,moved,axes=(1,0))
    return np.moveaxis(updated,0,axis).reshape(-1)

def simulate(n_qubits, operations):
    if n_qubits<1 or n_qubits>20: raise ValueError("State-vector simulator supports 1..20 qubits (memory grows as 2^n)")
    state=np.zeros(2**n_qubits,complex); state[0]=1
    gates={"H":H,"X":X,"Y":Y,"Z":Z}
    for op in operations:
        name=op["gate"].upper(); target=int(op["target"])
        if name in gates: state=_apply_single(state,gates[name],target,n_qubits)
        elif name=="CNOT":
            control=int(op["control"])
            if control==target or min(control,target)<0 or max(control,target)>=n_qubits: raise ValueError("Invalid CNOT control/target")
            for idx in range(len(state)):
                if (idx>>control)&1 and not ((idx>>target)&1):
                    other=idx^(1<<target); state[idx],state[other]=state[other],state[idx]
        else: raise ValueError(f"Unsupported gate: {name}")
    probs=np.abs(state)**2
    return {"state_real":state.real.tolist(),"state_imag":state.imag.tolist(),"probabilities":probs.tolist(),
            "norm":float(np.vdot(state,state).real),"n_qubits":n_qubits,
            "basis_order":"computational basis; qubit 0 is least-significant bit"}
