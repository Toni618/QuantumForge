"""Finite-dimensional spin operators and density-matrix diagnostics."""
from __future__ import annotations
import numpy as np

I2 = np.eye(2, dtype=complex)
SIGMA_X = np.array([[0, 1], [1, 0]], dtype=complex)
SIGMA_Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
SIGMA_Z = np.array([[1, 0], [0, -1]], dtype=complex)
SPIN_HALF = {"Sx": 0.5 * SIGMA_X, "Sy": 0.5 * SIGMA_Y, "Sz": 0.5 * SIGMA_Z}

def density_matrix_diagnostics(rho, atol=1e-10):
    r = np.asarray(rho, dtype=complex)
    if r.ndim != 2 or r.shape[0] != r.shape[1] or r.shape[0] == 0:
        raise ValueError("Density matrix must be a non-empty square matrix")
    herm = float(np.linalg.norm(r-r.conj().T))
    trace = complex(np.trace(r))
    eig = np.linalg.eigvalsh((r+r.conj().T)/2)
    minimum = float(eig.min())
    valid = herm <= atol and abs(trace-1) <= atol and minimum >= -atol
    return {"valid_density_matrix": bool(valid), "trace_real": float(trace.real),
            "trace_imag": float(trace.imag), "hermiticity_residual": herm,
            "minimum_eigenvalue": minimum, "eigenvalues": eig.real.tolist(),
            "purity": float(np.trace(r@r).real)}

def bell_state_density():
    psi = np.array([1,0,0,1], dtype=complex)/np.sqrt(2)
    return np.outer(psi, psi.conj())
