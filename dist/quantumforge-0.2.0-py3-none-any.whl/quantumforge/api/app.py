from __future__ import annotations
import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from quantumforge import __version__
from quantumforge.core.expressions import parse_expression, ExpressionError
from quantumforge.math.solvers import find_root, integrate_function
from quantumforge.quantum.schrodinger import solve_1d, harmonic_oscillator
from quantumforge.quantum.circuits import simulate
from quantumforge.relativity.special import lorentz_boost, minkowski_interval
from quantumforge.relativity.black_holes import schwarzschild_parameters
from quantumforge.quantum.operators import SPIN_HALF, density_matrix_diagnostics, bell_state_density
from quantumforge.qft.lattice_scalar import free_scalar_lattice
from quantumforge.relativity.geodesics import schwarzschild_geodesic
from quantumforge.relativity.tensor_geometry import schwarzschild_metric
from quantumforge.storage.experiments import ExperimentStore

app=FastAPI(title="QuantumForge Local Scientific API",version=__version__)
app.add_middleware(CORSMiddleware, allow_origins=["tauri://localhost", "https://tauri.localhost", "http://localhost:5173", "http://127.0.0.1:5173"], allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["Content-Type"])
store=ExperimentStore(os.environ.get("QUANTUMFORGE_DB","quantumforge.sqlite3"))
class RootRequest(BaseModel): expression:str; variable:str="x"; bracket:tuple[float,float]; xtol:float=Field(1e-10,gt=0)
class SchrodingerRequest(BaseModel): x_min:float=-8; x_max:float=8; points:int=1201; states:int=6; omega:float=1.0
class CircuitRequest(BaseModel): n_qubits:int=Field(ge=1,le=20); operations:list[dict]
class BlackHoleRequest(BaseModel): mass_kg:float=Field(gt=0)
class QFTRequest(BaseModel): mass:float=Field(ge=0); sites:int=Field(default=64,ge=4,le=4096); spacing:float=Field(default=0.25,gt=0)
class GeodesicRequest(BaseModel): r0:float=Field(gt=2); energy:float=Field(gt=0); angular_momentum:float=0; radial_velocity:int=Field(default=-1,ge=-1,le=1); affine_end:float=Field(default=50,gt=0,le=10000); samples:int=Field(default=1000,ge=20,le=20000); kind:str="timelike"
class DensityRequest(BaseModel): real:list[list[float]]; imag:list[list[float]]|None=None
@app.get("/health")
def health(): return {"status":"ok","version":__version__,"scientific_backend":"python"}
@app.post("/math/root")
def root(req:RootRequest):
    try: return find_root(req.expression,req.variable,req.bracket,req.xtol)
    except Exception as e: raise HTTPException(422,str(e))
@app.post("/math/integrate")
def integrate(req:RootRequest):
    try: return integrate_function(req.expression,req.variable,*req.bracket,epsabs=req.xtol,epsrel=req.xtol)
    except Exception as e: raise HTTPException(422,str(e))
@app.post("/quantum/schrodinger/harmonic")
def schrodinger(req:SchrodingerRequest):
    try: return solve_1d(lambda x:harmonic_oscillator(x,req.omega),req.x_min,req.x_max,req.points,req.states)
    except Exception as e: raise HTTPException(422,str(e))
@app.post("/quantum/circuit")
def circuit(req:CircuitRequest):
    try: return simulate(req.n_qubits,req.operations)
    except Exception as e: raise HTTPException(422,str(e))
@app.post("/relativity/lorentz")
def lorentz(beta:list[float]):
    try:
        m=lorentz_boost(beta); eta=__import__('numpy').diag([-1,1,1,1]); residual=float(__import__('numpy').linalg.norm(m.T@eta@m-eta))
        return {"matrix":m.tolist(),"metric_invariance_residual":residual,"convention":"metric (-,+,+,+); beta=v/c"}
    except Exception as e: raise HTTPException(422,str(e))
@app.post("/relativity/schwarzschild")
def black_hole(req:BlackHoleRequest):
    try: return schwarzschild_parameters(req.mass_kg)
    except Exception as e: raise HTTPException(422,str(e))
@app.post("/experiments")
def save_experiment(payload:dict):
    if not all(k in payload for k in ("model","config","result")): raise HTTPException(422,"Expected model, config, result")
    try: return store.save(payload["model"],payload["config"],payload["result"])
    except Exception as e: raise HTTPException(422,str(e))
@app.get("/experiments/{experiment_id}")
def get_experiment(experiment_id:str):
    try: return store.get(experiment_id)
    except KeyError: raise HTTPException(404,"Experiment not found")

def run():
    import uvicorn
    uvicorn.run(app,host="127.0.0.1",port=int(os.environ.get("QUANTUMFORGE_PORT","8765")),log_level="info")

@app.get("/quantum/spin/operators")
def spin_operators():
    return {name:{"real":m.real.tolist(),"imag":m.imag.tolist()} for name,m in SPIN_HALF.items()}
@app.post("/quantum/density/diagnostics")
def density_diagnostics(req:DensityRequest):
    import numpy as np
    try:
        rho=np.asarray(req.real,dtype=float).astype(complex)
        if req.imag is not None: rho += 1j*np.asarray(req.imag,dtype=float)
        return density_matrix_diagnostics(rho)
    except Exception as e: raise HTTPException(422,str(e))
@app.get("/quantum/density/bell")
def bell_density():
    rho=bell_state_density()
    return {"real":rho.real.tolist(),"imag":rho.imag.tolist(),"diagnostics":density_matrix_diagnostics(rho)}
@app.post("/qft/free-scalar-lattice")
def qft_free_scalar(req:QFTRequest):
    try: return free_scalar_lattice(req.mass,req.sites,req.spacing)
    except Exception as e: raise HTTPException(422,str(e))
@app.post("/relativity/schwarzschild/geodesic")
def geodesic(req:GeodesicRequest):
    try: return schwarzschild_geodesic(req.r0,req.energy,req.angular_momentum,req.radial_velocity,req.affine_end,req.samples,req.kind)
    except Exception as e: raise HTTPException(422,str(e))
@app.get("/relativity/schwarzschild/geometry")
def schwarzschild_geometry():
    try: return schwarzschild_metric()
    except Exception as e: raise HTTPException(422,str(e))

if __name__ == "__main__":
    run()
