"""Exact Schwarzschild scalars and explicitly labelled test-particle landmarks."""
G=6.67430e-11
C=299_792_458.0
HBAR=1.054571817e-34
K_B=1.380649e-23

def schwarzschild_parameters(mass_kg: float):
    if mass_kg<=0: raise ValueError("Mass must be positive")
    rs=2*G*mass_kg/C**2
    return {"mass_kg":mass_kg,"schwarzschild_radius_m":rs,"photon_sphere_radius_m":1.5*rs,
            "isco_radius_m":3*rs,"hawking_temperature_K":HBAR*C**3/(8*3.141592653589793*G*mass_kg*K_B),
            "model":"Schwarzschild vacuum black hole; non-rotating, uncharged",
            "status":"Exact analytic expressions for the stated idealized spacetime"}
