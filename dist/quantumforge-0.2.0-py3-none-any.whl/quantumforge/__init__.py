"""QuantumForge scientific computing package."""
__version__ = "0.2.0"
