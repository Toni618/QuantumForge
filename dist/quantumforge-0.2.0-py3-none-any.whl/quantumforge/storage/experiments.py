"""SQLite-backed experiment metadata and content-addressed JSON records."""
import sqlite3, json, hashlib, datetime
from pathlib import Path

class ExperimentStore:
    def __init__(self,path="quantumforge.sqlite3"):
        self.path=str(path); Path(self.path).parent.mkdir(parents=True,exist_ok=True)
        with self._connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS experiments (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, model TEXT NOT NULL, config_json TEXT NOT NULL, result_json TEXT NOT NULL, sha256 TEXT NOT NULL)")
    def _connect(self):
        db=sqlite3.connect(self.path); db.row_factory=sqlite3.Row; return db
    def save(self, model, config, result):
        payload=json.dumps({"model":model,"config":config,"result":result},sort_keys=True,separators=(",",":"),allow_nan=False)
        digest=hashlib.sha256(payload.encode()).hexdigest(); eid=digest[:16]
        with self._connect() as db:
            db.execute("INSERT OR REPLACE INTO experiments VALUES (?,?,?,?,?,?)",(eid,datetime.datetime.now(datetime.timezone.utc).isoformat(),model,json.dumps(config,sort_keys=True,allow_nan=False),json.dumps(result,sort_keys=True,allow_nan=False),digest))
        return {"id":eid,"sha256":digest}
    def get(self,eid):
        with self._connect() as db: row=db.execute("SELECT * FROM experiments WHERE id=?",(eid,)).fetchone()
        if row is None: raise KeyError(eid)
        return dict(row)
